package Order;

public class ItalianCousine extends Cousines implements GetNP{

	@Override
	public void getName() {
		
		
	}

	@Override
	public void getPrice() {
		
		
	}

}
