package Order;

public class IceCubesPlusLemon implements Make{

	@Override
	public String make() {
		String iceCubesPlusLemon = "Ice Cubes plus Lemon";
		
		return iceCubesPlusLemon;
	}

}
