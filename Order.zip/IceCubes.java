package Order;

public class IceCubes implements Make{

	@Override
	public String make() {
		String iceCubse = "Ice Cubse";
		
		return iceCubse;
	}

	
	
	
	

}
