package Order;

public class Lemon implements Make{

	@Override
	public String make() {
         String lemon = "Lemon";
		
		return lemon;
		
	}


	

}
