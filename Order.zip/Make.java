package Order;

public interface Make {
	
	public String make();

}
