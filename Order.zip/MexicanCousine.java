package Order;

public class MexicanCousine extends Cousines implements GetNP{

	@Override
	public void getName() {
		
		
	}

	@Override
	public void getPrice() {
		
		
	}

}
