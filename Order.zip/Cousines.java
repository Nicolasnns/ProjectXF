package Order;

public abstract class Cousines {
	 String name = "";
	 Double price = 0.0;
	
	public void makeTheMenu(String name, Double price){
		
		this.name = name;
		this.price = price;
		
	}

}
