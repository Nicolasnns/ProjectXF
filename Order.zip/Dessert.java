package Order;

public class Dessert implements Make{

	@Override
	public String make() {

		String dessert = "Dessert";
		
		return dessert;
	}

	

}
