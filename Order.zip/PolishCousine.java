package Order;

public class PolishCousine extends Cousines implements GetNP{
	

	@Override
	public void getName() {
		
		
	}

	@Override
	public void getPrice() {
		
		
	}

}
