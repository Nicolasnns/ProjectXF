package Order;

public class MainCourse implements Make{

	@Override
	public String make() {
		
      String mainCourse = "Main Course";
		
		return mainCourse;
	}

	
	

}
