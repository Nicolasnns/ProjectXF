package Order;

public interface GetNP {

	public void getName();

	public void getPrice();
}
